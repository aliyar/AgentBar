# Changelog

All notable changes to AgentBar are documented here. The format follows
[Keep a Changelog](https://keepachangelog.com/en/1.1.0/), versions follow [Semantic Versioning](https://semver.org/).

Add entries under **Unreleased** as you work; `scripts/release.sh` moves them under the new
version heading and uses them as the release notes.

## [Unreleased]

## [1.1.0] - 2026-09-03

### Added
- **What is left once a plan runs out.** Claude's extra usage and its prepaid credits
  become a row of their own, and Codex's balance is said beside the agent's name — both
  only when the account actually holds them, so a panel without credits is unchanged.
  Codex writes its balance into every session it runs, so it is read without asking the
  account at all.
- Codex's model-specific limits (`additional_rate_limits`) are shown among the plan's own
  windows, named for what tells them apart: GPT-5.3-Codex-Spark reads "Session · Spark" and
  "Weekly · Spark". Resting on the row gives the model's whole name.
- **The account beside the agent's name**: the plan as a small badge — "Max 20x", "Pro
  Lite", "Free" — and, on resting there, who is signed in. Quiet enough to be read second;
  it answers "whose numbers are these?" without taking a row. Every part of it is already
  on this Mac, beside the sign-ins the agents keep, so none of it costs a request. Cursor's
  monthly row is now just "Monthly", since the plan it used to carry is said above it.
- Cursor reads the figures every plan reports, not only an individual's: a team member's
  personal cap and the pool a team spends from each fill the monthly bar that was empty
  before, and an unlimited plan says so instead of drawing a percentage of no ceiling.

### Changed
- **One name per window, one order for every row.** A window is named for the period it
  runs — "5h", "Weekly", "Monthly" — and what it is scoped to follows it: "Weekly · all",
  "Weekly · Fable", "5h · Spark". Rows are ordered by how long their window runs, shortest
  first, and within one window the plan's own row comes before the models that meter their
  own; what is spent once the plan is full sorts last, having no window at all. Codex
  previously called its short window "Session (5h)" while a model's read "5h · Spark", and
  listed every plan window before every model one, so the same length appeared twice in a
  list that looked sorted.
- **The panel draws its own tooltips.** `help(_:)` waits out the system's delay — over a
  second, not ours to set — and draws in the system's yellow; inside a panel that answers
  a glance, that is the whole visit. Tips now appear in a third of the time, in the
  panel's own materials, placed against the row they belong to and kept inside the
  panel's edges.
- The agent's name in the panel is the link to its usage page. The small arrow that
  appeared beside it on hover is gone: it was a second thing to find for what the name was
  already pointing at.

### Fixed
- **The website on a phone.** The page could be scrolled sideways: the callouts beside the
  drawn panel reached past the viewport, and the laptop kept its negative margins. The
  widgets inside the laptop drew at full size on iOS, where nested `zoom` dropped the inner
  scale — the inner layers use a transform now, which is scaled once and reliably. Section
  headings and the questions were still at their desktop size on a 390 pt screen. The
  callouts are left out below 420 pt, where a marker over a row covers the very figure it
  points at; the notes below keep their numbers and read in the same order.
- **A panel on the website closes when you press away from it**, or on Escape, as a menu on
  the Mac does. The Dock's panel could only be closed from the Dock icon that opened it.
- The website drew windows the app no longer names that way ("Daily" for Codex, "Pro ·
  monthly" for Cursor), and said Codex reports a daily window. It reports a 5-hour one.
- `next build` wrote `AGENTS.md` and `CLAUDE.md` into `site/` on every run; this project
  keeps its instructions in the notes repo (`agentRules: false`).
- Codex's 5-hour window was labelled "Daily" — a window named after a period four times
  its own. It reads "5h".
- Claude's session and weekly windows are read from the account's own named fields again.
  A `limits` array carrying only a model-scoped week used to replace them, which would
  have dropped the session row entirely. Scoped weeks still come from that array, and a
  scope naming every model no longer draws the weekly window a second time.
- The terminal style wrote "—" against a limit that starts over on no date anyone writes.
  The dash means a window has rolled over; the column is now blank for limits that have
  no reset at all.
- Codex's windows are ordered shortest first, as Claude's are. Its `primary` window is not
  always the shorter one — on some plans it is the week.

### Changed
- The website's link preview and its search metadata: the Open Graph card now states the
  image's size, type and alt text, so Slack, iMessage, X and LinkedIn draw the large card on
  the first fetch; the privacy and terms pages carry their own title, description and URL
  instead of the home page's; and the home page carries `SoftwareApplication`, `WebSite`,
  `Organization` and `FAQPage` structured data, a theme colour and a crawler directive that
  lets Google show the card image full size.

## [1.0.1] - 2026-09-03

### Changed
- The defaults a first launch lands on: the menu bar gauge (bars and the time left) on,
  the app in the menu bar and the Dock both, and launch at login registered on the first
  run. Each can be turned off in Settings.

## [1.0.0] - 2026-09-03

### Added
- The app: a menu bar item, a popover, and a Settings window with the update controls.
- **The icon**: a dark terminal squircle holding the app's own panel, a `>` prompt and a
  green block cursor. The menu bar shows the same mark; so does the panel's header.
- **The limits come from the agents' accounts**, so what was spent on another Mac or while
  the agent was not running counts too: Claude through Claude Code's sign-in, Codex through
  its ChatGPT sign-in, Cursor through the editor's. One read-only request every five
  minutes, and on the panel's refresh button; nothing is stored. What the agents write on
  disk stays the fallback.
- **Cursor** joins Claude Code and Codex: its plan's monthly usage, and its agent chats
  among the active conversations.
- **Where the app lives is a choice**: Settings › General › "Show AgentBar in" the menu
  bar (default), the Dock, or both. In the Dock, clicking the icon opens the panel above
  the Dock, as the menu bar icon does, or a window if you prefer (the choice is in the Dock
  icon's right-click menu too); Window › AgentBar (⌘0) and the widget open the window,
  whose header stands in for its title bar.
- **A widget** for Notification Center and the desktop, in three sizes: each agent's
  fullest window with its meter and time left; every window as a row; the rows and the
  running conversations. Right-click › Edit "AgentBar" picks the windows to show (any
  set; none means all), a theme (system, dark or light) and, for the large size, whether
  the running conversations are listed. A size left with a single window shows it as a
  card: the figure large, a wide meter, the time left. When there are more windows than
  a size has rows, it shows each agent's fullest rather than dropping the last agents.
  It shows what the app last read and says "as of" when that is old; tapping a
  conversation brings its terminal or editor forward.
- **The panel shows what the coding agents on this Mac are doing.** For Claude Code and
  Codex: every rate-limit window as a meter that fills as you spend, the percentage, and
  how long until it starts over; and the conversations running right now, named by what
  was last said in them, with a pulsing dot while one is working and how full its context
  is. Clicking a conversation opens its details; clicking again brings its terminal or
  editor forward. Codex sessions are found through their running process and its rollout;
  their context is a real percentage, since Codex writes its window size.
- **The panel is glass**, in a dark and a light variant: a header with the agent and
  window count and when the files were last read; each agent's windows as rows in a
  rounded group (label, meter, percent, time left; click a time to see the clock
  time it starts over instead, or pick the default in Settings › Appearance); the running conversations with the
  agent's mark, a breathing dot while one works, its context and a chevron for the
  details; and a footer with Settings and Quit.
- The menu bar can show a gauge instead of the symbol: a small bar per window and the
  time left on one of them, in its colour. Settings › Appearance › Menu Bar chooses the
  windows shown as bars and whose time left is written (the fullest, a given window, or
  none). Off by default.
- Settings, laid out like System Settings with a sidebar: General (launch at login,
  appearance, the menu bar percentage, updates), Agents (which agents to show), Changelog
  (these notes, inside the app), Support and About. Back and forward buttons walk the
  panes you visited.
- **Appearance**: System, Light or Dark for the popover and the Settings window. The menu
  bar item always follows the menu bar.
- **Style**: how the panel is drawn, apart from the theme. Glass (the design) or Terminal
  (a terminal readout: monospaced, green on black, `▌` meters, a blinking prompt); each
  has a light and a dark variant and the theme picks which, Dark by default. A background
  opacity slider (0–100%) sets how sheer either panel is.
- **Launch at login**, through the system's Login Items.
- Hover an agent's name in the panel and a small arrow (Terminal: `:usage`) appears; it
  opens that agent's own usage page in the browser.
- The Active group stays when nothing is running and says so, so the panel keeps its
  shape; a context at "100%" no longer wraps; while a refresh runs, the clock in the
  header walks "..." (the Terminal panel's `:r` flashes when clicked, too).
- Nothing is shown that cannot be stood behind: a window that has already started over
  shows "—", a figure written hours ago says how old it is, and a context whose limit is
  not written anywhere reports its tokens instead of a made-up percentage.

[Unreleased]: https://github.com/aliyar/AgentBar/compare/v1.1.0...HEAD
[1.0.0]: https://github.com/aliyar/AgentBar/releases/tag/v1.0.0
[1.0.1]: https://github.com/aliyar/AgentBar/releases/tag/v1.0.1
[1.1.0]: https://github.com/aliyar/AgentBar/releases/tag/v1.1.0
